
-- =============================================

-- Author:	Jordy, Viviana, Shirley y Jeannette

-- Create date: 28/11/2020

-- Description:	Proyecto Final

-- =============================================


CREATE DATABASE BIBLIOTECA2
GO

--LLAMADO DE LA BASE DE DATOS
USE BIBLIOTECA2
GO

-- CREACION DE TABLAS
CREATE TABLE Libro
(
    IdLibro INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
    Titulo VARCHAR (50) NOT NULL,
	Editorial VARCHAR (50) NOT NULL,
	Area VARCHAR (50) NOT NULL
);

CREATE TABLE Autor
(
	IdAutor INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Nombre VARCHAR (50) NOT NULL,
	Nacionalidad VARCHAR (50) NOT NULL
);


CREATE TABLE LibAut
(
   IdAutor INT  FOREIGN KEY REFERENCES Autor(IdAutor) NOT NULL,
   IdLibro INT FOREIGN KEY REFERENCES Libro (IdLibro)
   
);

CREATE TABLE Estudiante
(
	IdLector INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CI VARCHAR (30) NOT NULL,
	Apellido VARCHAR (30) NOT NULL,
	Nombre VARCHAR (50) NOT NULL,
	Direccion VARCHAR (50) NOT NULL,
	Carrera VARCHAR (50) NOT NULL,
	Edad INT NOT NULL
);

CREATE TABLE Prestamo
(
	IdLector INT FOREIGN KEY REFERENCES Estudiante (IdLector) NOT NULL,
	IdLibro INT FOREIGN KEY REFERENCES Libro (IdLibro),
	FechaPrestamo DATETIME NOT NULL,
	FechaDevolucion DATETIME NOT NULL,
	Devuelto CHAR NOT NULL
);


--INSERTAR DATOS LIBROS

INSERT INTO Libro (Titulo, Editorial, Area)
VALUES
	  ('Marco Jur�dico de la Inform�tica', 'Editorial UCR','Inform�tica'),
	  ('Los le�os vivientes' ,'Editorial Costa Rica','Novela'), 
	  ('El Libro negro de la Nueva Izquierda' ,'Grupo Uni�n','Filosof�a'), 
	  ('Bajo la Lluvia Dios no Existe','Uruk Editores','Novela'), 
	  ('Visual Studio Net','Editorial Alfa y Omega','Inform�tica'), 
	  ('Los Ojos del Drag�n','Editorial Penguin Random House','Novela'), 
	  ('El Sentido de la Vida','Editorial Paidos','Filosof�a');
INSERT INTO Libro (Titulo, Editorial, Area)
VALUES
	  ('Base de Datos', 'Editorial UCR','Internet');

	  --COMPROBACION
	  --SELECT * FROM Libro

--INSERTAR DATOS AUTOR
	  INSERT INTO Autor
           (Nombre,Nacionalidad)
     VALUES
           ('Marta Eunice Calder�n', 'Costa Rica'),
		   ('Fabio Dobles', 'Costa Rica'),
		   ('Agustin Laje', 'Argentina'),
		   ('Warren Ulloa Arg�ello', 'Costa Rica'),
		   ('Mario Benedetti', 'Uruguay'),
		   ('Stephen King', 'USA'),
		   ('Terry Eagleton', 'Francia');

--COMPROBACION 		   
--select * from Autor
--select * from LibAut
select * from Autor
select * from libro

--INSERTAR DATOS LIBROS

INSERT INTO LibAut
           (IdAutor, IdLibro)
     VALUES
           (1, 1),
		   (2, 2),
		   (3, 3),
		   (4, 4),
		   (5, 5),
		   (6, 6),
		   (7, 7),
		   (5, 8);

	  --COMPROBACION 
	  --SELECT * FROM LibAut
	  --SELECT * FROM Autor
	  --SELECT * FROM Libro




--INSERTAR DATOS ESTUDIANTE

INSERT INTO Estudiante
           (CI,Nombre, Apellido, Direccion, Carrera, Edad)
     VALUES
           ('206980099', 'Jeannette', 'Garc�a Varela', 'San Ram�n-Alajuela', 'Inform�tica', '29'),
		   ('107980079', 'Jordy', 'Ulate Rojas', 'San Pedro-San Jos�', 'Administraci�n', '23'),
		   ('607980079', 'Shirley', 'Delgado Sibaja', 'Guadalupe-San Jos�', 'Aduanas', '22'),
		   ('407980079', 'Viviana', 'Villa De Mora', 'Santa Barbara-Heredia', 'Educaci�n del Ingl�s', '30'),
		   ('507980079', 'Felipe', 'Loayza Beramendi', 'Juanito Mora-Puntarenas', 'Ciencias Pol�ticas', '35');

	 --COMPROBACION 
	  --SELECT * FROM Estudiante

--INSERTAR DATOS PRESTAMO

		   INSERT INTO Prestamo
           (IdLector, IdLibro, FechaPrestamo, FechaDevolucion, Devuelto)
     VALUES
           (3, 5, '10-03-07', '10-04-07', 'Y'),
		   (5, 8, '10-03-07', '10-04-07', 'Y'),
		   (1, 4, '11-04-19', '11-05-19', 'N'),
		   (4, 6, '05-06-19', '05-07-19', 'N'),
		   (5, 3, '12-06-20', '12-07-20', 'Y'),
		   (4, 6, '11-05-20', '11-06-20', 'N'),
		   (2, 3, '08-06-20', '08-06-20', 'Y'),
		   (1, 6, '04-20-18', '04-21-18', 'N'),
		   (2, 7, '10-03-07', '10-04-07', 'Y');
		   
		
	--COMPROBACION 
	  --SELECT * FROM Prestamo
	  --SELECT * FROM Estudiante
	  SELECT * FROM Libro
	  SELECT * FROM LibAut

 	   	  	

--CONSULTAS

--1. Listar los datos de los autores que tengan m�s de un libro publicados

CREATE VIEW V_AutoresConMasDeUnLibro
AS
    SELECT count (LA.IdAutor) as 'La cantidad de libros', A.Nombre, A.Nacionalidad  
FROM Libro as L 
Inner Join LibAut as LA on L.IdLibro= LA.IdLibro
Inner Join Autor as A on A.IdAutor=LA.IdAutor
Group by  LA.IdAutor, A.Nombre, A.Nacionalidad 
Having Count (LA.IdAutor) > 1



--2. Listar nombre y edad de los estudiantes

CREATE VIEW V_NameEdadEstudiantes
AS
    Select E.Nombre, E.Edad
From Estudiante as E



--3. �Qu� estudiantes pertenecen a la carrera de Inform�tica?

CREATE VIEW v_EstudiantesInformatica
AS
    Select *
From Estudiante as E
Where E.Carrera like 'Inform�tica'



--4. Listar los nombres de los estudiantes cuyo apellido comience con la letra G?

CREATE VIEW V_EstudiantesApellidoG
AS
   Select *
From Estudiante as E
Where E.Apellido like 'G%'



--5. �Qui�n es el autor del libro �Visual Studio Net�, listar sola mente el nombre?


CREATE VIEW V_AutorVisualStudioNet
AS
    select A.Nombre from Autor as A
Inner join LibAut as LA on A.IdAutor=LA.IdAutor
inner join Libro as L on L.IdLibro=LA.IdLibro
Where titulo like 'Visual Studio Net'



--6. �Qu� autores son de nacionalidad USA o Francia?

CREATE VIEW V_AutoresUSAOrFrancia
AS
    Select A.Nombre, A.Nacionalidad
From Autor as A
Where A.Nacionalidad in ('USA','Francia')



--7.�Qu� libros No Son del �rea de Internet?

CREATE VIEW V_LibrosNoAreaInternet
AS
    Select L.Titulo 
From Libro as L 
where L.Area !='Internet'



--8. �Qu� libros se prest� el Lector �Felipe Loayza Beramendi�?


CREATE VIEW V_PrestamosAFelipe
AS
    Select E.Nombre,E.Apellido,L.Titulo
From Libro as L
Inner join Prestamo as P on L.IdLibro=P.IdLibro
Inner join Estudiante as E on E.IdLector=P.IdLector
Where E.Nombre like 'Felipe';



--9. Listar el nombre del estudiante de menor edad

CREATE VIEW V_EstudiantesMenorEdad
AS
    Select E.Nombre As 'El estudiante de menor edad es:' from Estudiante as E
where E.Edad =(Select min (Edad) from Estudiante )



--10. Listar los nombres de los estudiantes que se prestaron Libros de Base de Datos

CREATE VIEW V_NombresEstudiantesConPrestamosDB
AS
    Select P.IdLector, E.Nombre, E.Apellido,L.Titulo
From Estudiante as E
Inner join Prestamo as P on P.IdLector=E.IdLector
Inner join Libro as L on L.IdLibro=P.IdLibro
Where L.Titulo like 'Base de Datos';



--11. Listar los libros de editorial Alfa y Omega

CREATE VIEW V_LibrosEditorialAlfaOmega
AS
    Select L.Titulo
From Libro as L
Where L.Editorial like '%Alfa y Omega%'



--12. Listar los libros que pertenecen al autor Mario Benedetti

CREATE VIEW V_LibroDeMarioBenedetti
AS
    Select L.Titulo,A.Nombre
From Libro as L
inner join LibAut as LA on L.IdLibro=LA.IdLibro
inner join Autor as A on LA.IdAutor=A.IdAutor
Where A.Nombre like 'Mario Benedetti'



--13. Listar los t�tulos de los libros que deb�an devolverse el 10/04/07

CREATE VIEW V_LibrosDevolverCiertaFecha
AS
    Select L.Titulo, P.FechaDevolucion
From Libro as L
inner join Prestamo as P on P.IdLibro=L.IdLibro
Where P.FechaDevolucion = '10/04/07'



--14. Hallar la suma de las edades de los estudiantes

CREATE VIEW V_SumaEdadesEstudiantes
AS
    Select sum(E.Edad) as 'La suma de las edades es:'
From Estudiante as E



--15. Listar los datos de los estudiantes cuya edad es mayor al promedio

CREATE VIEW V_EstudiantesEdadMayorAlPromedio
AS
    Select*
from Estudiante where Edad>(select AVG(Edad) from Estudiante)



--16. Crear un Procedimiento Almacenado que muestre los libros 
--de un determinado Autor que se especifique.
go

CREATE PROCEDURE LibrosdeAutor

    @NombreAutor Varchar (50)   
AS

-- CORRECTO TRYBEGIN TRY	--INICIA LA TRANSACCION	BEGIN TRANSACTION G;	 SELECT L.Titulo, A.Nombre	 From Libro as L	 Inner join LibAut as LA on L.IdLibro=LA.IdLibro	 Inner join Autor as A on LA.IdAutor=A.IdAutor	 Where A.Nombre=@NombreAutor	 	-- EXITOSO	COMMIT TRANSACTION G;END TRY-- EN CASO DE ERRORBEGIN CATCH	-- EN CASO DE ERROR SE DEVUELVE	ROLLBACK TRANSACTION G;	RAISERROR('Error: ',1,16)END CATCH--Execute LibrosdeAutor 'Warren Ulloa Arg�ello'--17. Crear un Procedimiento Almacenado que inserte nuevos Estudiantes
go

CREATE PROCEDURE InserteEstudiante	@CI VARCHAR (30),
	@Apellido VARCHAR (30),
	@Nombre VARCHAR (50),
	@Direccion VARCHAR (50),
	@Carrera VARCHAR (50),
	@Edad INTAS
   	-- CORRECTO TRYBEGIN TRY	--INICIA LA TRANSACCION	BEGIN TRANSACTION E;	Insert into Estudiante (CI, Apellido, Nombre, Direccion, Carrera,Edad)	Values (@CI, @Apellido, @Nombre, @Direccion, @Carrera, @Edad)	   	-- EXITOSO	COMMIT TRANSACTION E;END TRY-- EN CASO DE ERRORBEGIN CATCH	-- EN CASO DE ERROR SE DEVUELVE	ROLLBACK TRANSACTION E;	RAISERROR('Error: ',1,16)END CATCH
--Execute InserteEstudiante '708980090', 'Aaron', 'Martinez', 'Puntarena', 'Ing.Industrial', '32'

--18. Crear un Procedimiento Almacenado que actualice cualquier 
--Libro especificando su c�digo.
go 

CREATE PROCEDURE ActualizarLibro

    @Titulo VARCHAR (50),
	@Editorial VARCHAR (50),
	@Area VARCHAR (50),	@LibroID int=0AS-- CORRECTO TRYBEGIN TRY	--INICIA LA TRANSACCION	BEGIN TRANSACTION L;	Begin	Update Libro 		Set Titulo=@Titulo,	    Editorial= @Editorial,	    Area = @Area	Where IdLibro= @LibroID	End	-- EXITOSO	COMMIT TRANSACTION L;END TRY-- EN CASO DE ERRORBEGIN CATCH	-- EN CASO DE ERROR SE DEVUELVE	ROLLBACK TRANSACTION L;	RAISERROR('Error: ',1,16)END CATCH--COMPROBACIONSelect * From Libro--19. Crear un disparador DML que permita listar los registros de la TablaEstudiantes luego de insertar un nuevo registro.

CREATE TRIGGER Tri_ListaEstudiantes
    ON [dbo].[Estudiante]
    FOR INSERT
    AS
    BEGIN
    SELECT * FROM ESTUDIANTE
    END

INSERT INTO Estudiante
           (CI,Nombre, Apellido, Direccion, Carrera, Edad)
     VALUES
		   ('909980099', 'Margarito', 'Mora Hidalgo', 'Juanito Mora-Puntarenas', 'Ciencias Pol�ticas', '26');


--20. Crear una Funci�n (que devuelva una Tabla) que liste los pr�stamos solicitados por un determinado alumno.


CREATE FUNCTION F_DevuelvePrestamosPorAlumno
(
    @IdLector int 
)
RETURNS TABLE AS RETURN
(
	
    SELECT E.Nombre NOMBRE, E.Apellido APELLIDO, L.Titulo TITULO, P.FechaPrestamo FECHA_PRESTAMO  FROM Prestamo AS P
	INNER JOIN Estudiante as E ON E.IdLector=P.IdLector
	INNER JOIN Libro AS L ON L.IdLibro=P.IdLibro
	WHERE E.IdLector=@IdLector
	GROUP BY E.Nombre, E.Apellido, L.Titulo, P.FechaPrestamo
)

SELECT * FROM F_DevuelvePrestamosPorAlumno (1);
