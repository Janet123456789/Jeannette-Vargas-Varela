﻿using Bibliotecas.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Metadata.Edm;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Bibliotecas
{
    public partial class VentanaPrincipal : Form
    {
        public VentanaPrincipal()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_FormLibros_Click(object sender, EventArgs e)
        {
            FormLibro fL = new FormLibro();
            fL.Visible = true;
        }

        private void lb_SubTituloVentanaPrincipal_Click(object sender, EventArgs e)
        {

        }

        private void btn_FormEstudiante_Click(object sender, EventArgs e)
        {
            FormEstudiante fE = new FormEstudiante();
            fE.Visible = true;

        }

        private void VentanaPrincipal_Load(object sender, EventArgs e)
        {
             var conexion = new BIBLIOTECA2Entities();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void panel_VP_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }
    }
}
