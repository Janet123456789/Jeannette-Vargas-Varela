﻿namespace Bibliotecas
{
    partial class VentanaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_TituloVentanaPrincipal = new System.Windows.Forms.Label();
            this.btn_FormEstudiante = new System.Windows.Forms.Button();
            this.btn_FormLibros = new System.Windows.Forms.Button();
            this.lb_SubTituloVentanaPrincipal = new System.Windows.Forms.Label();
            this.lb_welcome = new System.Windows.Forms.Label();
            this.panel_VP = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Close = new System.Windows.Forms.PictureBox();
            this.lb_copyRigth = new System.Windows.Forms.Label();
            this.panel_VP.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_Close)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_TituloVentanaPrincipal
            // 
            this.lb_TituloVentanaPrincipal.AutoSize = true;
            this.lb_TituloVentanaPrincipal.Font = new System.Drawing.Font("Berlin Sans FB", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TituloVentanaPrincipal.ForeColor = System.Drawing.Color.Black;
            this.lb_TituloVentanaPrincipal.Location = new System.Drawing.Point(41, 77);
            this.lb_TituloVentanaPrincipal.Name = "lb_TituloVentanaPrincipal";
            this.lb_TituloVentanaPrincipal.Size = new System.Drawing.Size(347, 40);
            this.lb_TituloVentanaPrincipal.TabIndex = 24;
            this.lb_TituloVentanaPrincipal.Text = "Formulario Biblioteca";
            this.lb_TituloVentanaPrincipal.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lb_TituloVentanaPrincipal.UseWaitCursor = true;
            this.lb_TituloVentanaPrincipal.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_FormEstudiante
            // 
            this.btn_FormEstudiante.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_FormEstudiante.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_FormEstudiante.FlatAppearance.BorderColor = System.Drawing.Color.MediumBlue;
            this.btn_FormEstudiante.FlatAppearance.BorderSize = 0;
            this.btn_FormEstudiante.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightBlue;
            this.btn_FormEstudiante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_FormEstudiante.Font = new System.Drawing.Font("Berlin Sans FB", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FormEstudiante.ForeColor = System.Drawing.Color.Black;
            this.btn_FormEstudiante.Location = new System.Drawing.Point(32, 268);
            this.btn_FormEstudiante.Name = "btn_FormEstudiante";
            this.btn_FormEstudiante.Size = new System.Drawing.Size(144, 53);
            this.btn_FormEstudiante.TabIndex = 25;
            this.btn_FormEstudiante.Text = "Formulario Estudiante";
            this.btn_FormEstudiante.UseVisualStyleBackColor = false;
            this.btn_FormEstudiante.Click += new System.EventHandler(this.btn_FormEstudiante_Click);
            // 
            // btn_FormLibros
            // 
            this.btn_FormLibros.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_FormLibros.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_FormLibros.FlatAppearance.BorderSize = 0;
            this.btn_FormLibros.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightBlue;
            this.btn_FormLibros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_FormLibros.Font = new System.Drawing.Font("Berlin Sans FB", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FormLibros.ForeColor = System.Drawing.Color.Black;
            this.btn_FormLibros.Location = new System.Drawing.Point(233, 268);
            this.btn_FormLibros.Name = "btn_FormLibros";
            this.btn_FormLibros.Size = new System.Drawing.Size(144, 53);
            this.btn_FormLibros.TabIndex = 26;
            this.btn_FormLibros.Text = "Formulario Libros";
            this.btn_FormLibros.UseVisualStyleBackColor = false;
            this.btn_FormLibros.Click += new System.EventHandler(this.btn_FormLibros_Click);
            // 
            // lb_SubTituloVentanaPrincipal
            // 
            this.lb_SubTituloVentanaPrincipal.AutoSize = true;
            this.lb_SubTituloVentanaPrincipal.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SubTituloVentanaPrincipal.ForeColor = System.Drawing.Color.Black;
            this.lb_SubTituloVentanaPrincipal.Location = new System.Drawing.Point(96, 198);
            this.lb_SubTituloVentanaPrincipal.Name = "lb_SubTituloVentanaPrincipal";
            this.lb_SubTituloVentanaPrincipal.Size = new System.Drawing.Size(219, 22);
            this.lb_SubTituloVentanaPrincipal.TabIndex = 27;
            this.lb_SubTituloVentanaPrincipal.Text = "Seleccione un formulario";
            this.lb_SubTituloVentanaPrincipal.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lb_SubTituloVentanaPrincipal.Click += new System.EventHandler(this.lb_SubTituloVentanaPrincipal_Click);
            // 
            // lb_welcome
            // 
            this.lb_welcome.AutoSize = true;
            this.lb_welcome.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_welcome.ForeColor = System.Drawing.Color.Black;
            this.lb_welcome.Location = new System.Drawing.Point(125, 137);
            this.lb_welcome.Name = "lb_welcome";
            this.lb_welcome.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lb_welcome.Size = new System.Drawing.Size(157, 28);
            this.lb_welcome.TabIndex = 29;
            this.lb_welcome.Text = "¡Bienvenido!";
            this.lb_welcome.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lb_welcome.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // panel_VP
            // 
            this.panel_VP.BackColor = System.Drawing.Color.SteelBlue;
            this.panel_VP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_VP.Controls.Add(this.btn_Close);
            this.panel_VP.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_VP.Location = new System.Drawing.Point(0, 0);
            this.panel_VP.Name = "panel_VP";
            this.panel_VP.Size = new System.Drawing.Size(421, 53);
            this.panel_VP.TabIndex = 30;
            this.panel_VP.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_VP_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lb_copyRigth);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 352);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(421, 33);
            this.panel1.TabIndex = 31;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Transparent;
            this.btn_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Close.Image = global::Bibliotecas.Properties.Resources.baseline_close_black_18dp1;
            this.btn_Close.Location = new System.Drawing.Point(376, 9);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(29, 31);
            this.btn_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_Close.TabIndex = 3;
            this.btn_Close.TabStop = false;
            this.btn_Close.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // lb_copyRigth
            // 
            this.lb_copyRigth.ForeColor = System.Drawing.Color.LightGray;
            this.lb_copyRigth.Location = new System.Drawing.Point(102, 8);
            this.lb_copyRigth.Name = "lb_copyRigth";
            this.lb_copyRigth.Size = new System.Drawing.Size(209, 17);
            this.lb_copyRigth.TabIndex = 0;
            this.lb_copyRigth.Text = "© 2020 Shirley, Jordy Jeannette y Viviana";
            this.lb_copyRigth.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // VentanaPrincipal
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(421, 385);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_VP);
            this.Controls.Add(this.lb_welcome);
            this.Controls.Add(this.lb_SubTituloVentanaPrincipal);
            this.Controls.Add(this.btn_FormLibros);
            this.Controls.Add(this.btn_FormEstudiante);
            this.Controls.Add(this.lb_TituloVentanaPrincipal);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "VentanaPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.VentanaPrincipal_Load);
            this.panel_VP.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_Close)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_TituloVentanaPrincipal;
        private System.Windows.Forms.Button btn_FormEstudiante;
        private System.Windows.Forms.Button btn_FormLibros;
        private System.Windows.Forms.Label lb_SubTituloVentanaPrincipal;
        private System.Windows.Forms.Label lb_welcome;
        private System.Windows.Forms.Panel panel_VP;
        private System.Windows.Forms.PictureBox btn_Close;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lb_copyRigth;
    }
}