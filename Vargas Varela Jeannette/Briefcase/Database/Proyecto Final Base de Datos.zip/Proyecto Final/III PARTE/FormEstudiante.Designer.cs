﻿namespace Bibliotecas
{
    partial class FormEstudiante
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_Agregar = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_Eliminar = new System.Windows.Forms.Button();
            this.txt_Ci = new System.Windows.Forms.TextBox();
            this.txt_Apellido = new System.Windows.Forms.TextBox();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_Direccion = new System.Windows.Forms.TextBox();
            this.txt_Carrera = new System.Windows.Forms.TextBox();
            this.txt_Edad = new System.Windows.Forms.TextBox();
            this.lb_Cedula = new System.Windows.Forms.Label();
            this.lb_Apellido = new System.Windows.Forms.Label();
            this.lb_Nombre = new System.Windows.Forms.Label();
            this.lb_Direccion = new System.Windows.Forms.Label();
            this.lb_Carrera = new System.Windows.Forms.Label();
            this.lb_Edad = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_SmsEliminar = new System.Windows.Forms.Label();
            this.lb_TituloLista = new System.Windows.Forms.Label();
            this.pb_ReturnDelFormStudent = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ReturnDelFormStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.MenuHighlight;
            this.dataGridView1.Location = new System.Drawing.Point(13, 287);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(788, 163);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btn_Agregar
            // 
            this.btn_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Agregar.Location = new System.Drawing.Point(225, 207);
            this.btn_Agregar.Name = "btn_Agregar";
            this.btn_Agregar.Size = new System.Drawing.Size(75, 26);
            this.btn_Agregar.TabIndex = 1;
            this.btn_Agregar.Text = "Agregar";
            this.btn_Agregar.UseVisualStyleBackColor = true;
            this.btn_Agregar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_modificar
            // 
            this.btn_modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_modificar.Location = new System.Drawing.Point(351, 207);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(75, 26);
            this.btn_modificar.TabIndex = 2;
            this.btn_modificar.Text = "Modificar";
            this.btn_modificar.UseVisualStyleBackColor = true;
            this.btn_modificar.Click += new System.EventHandler(this.btn_modificar_Click);
            // 
            // btn_Eliminar
            // 
            this.btn_Eliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Eliminar.Location = new System.Drawing.Point(479, 207);
            this.btn_Eliminar.Name = "btn_Eliminar";
            this.btn_Eliminar.Size = new System.Drawing.Size(75, 26);
            this.btn_Eliminar.TabIndex = 3;
            this.btn_Eliminar.Text = "Eliminar";
            this.btn_Eliminar.UseVisualStyleBackColor = true;
            this.btn_Eliminar.Click += new System.EventHandler(this.button3_Click);
            // 
            // txt_Ci
            // 
            this.txt_Ci.Location = new System.Drawing.Point(278, 62);
            this.txt_Ci.Name = "txt_Ci";
            this.txt_Ci.Size = new System.Drawing.Size(100, 20);
            this.txt_Ci.TabIndex = 5;
            this.txt_Ci.TextChanged += new System.EventHandler(this.txt_Ci_TextChanged);
            // 
            // txt_Apellido
            // 
            this.txt_Apellido.Location = new System.Drawing.Point(450, 87);
            this.txt_Apellido.Name = "txt_Apellido";
            this.txt_Apellido.Size = new System.Drawing.Size(100, 20);
            this.txt_Apellido.TabIndex = 6;
            this.txt_Apellido.TextChanged += new System.EventHandler(this.txt_Apellido_TextChanged);
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Location = new System.Drawing.Point(278, 88);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(100, 20);
            this.txt_Nombre.TabIndex = 7;
            this.txt_Nombre.TextChanged += new System.EventHandler(this.txt_Nombre_TextChanged);
            // 
            // txt_Direccion
            // 
            this.txt_Direccion.Location = new System.Drawing.Point(278, 114);
            this.txt_Direccion.Name = "txt_Direccion";
            this.txt_Direccion.Size = new System.Drawing.Size(272, 20);
            this.txt_Direccion.TabIndex = 8;
            this.txt_Direccion.TextChanged += new System.EventHandler(this.txt_Direccion_TextChanged);
            // 
            // txt_Carrera
            // 
            this.txt_Carrera.Location = new System.Drawing.Point(278, 140);
            this.txt_Carrera.Name = "txt_Carrera";
            this.txt_Carrera.Size = new System.Drawing.Size(272, 20);
            this.txt_Carrera.TabIndex = 9;
            this.txt_Carrera.TextChanged += new System.EventHandler(this.txt_Carrera_TextChanged);
            // 
            // txt_Edad
            // 
            this.txt_Edad.Location = new System.Drawing.Point(450, 61);
            this.txt_Edad.Name = "txt_Edad";
            this.txt_Edad.Size = new System.Drawing.Size(100, 20);
            this.txt_Edad.TabIndex = 10;
            this.txt_Edad.TextChanged += new System.EventHandler(this.txt_Edad_TextChanged);
            // 
            // lb_Cedula
            // 
            this.lb_Cedula.AutoSize = true;
            this.lb_Cedula.Location = new System.Drawing.Point(218, 68);
            this.lb_Cedula.Name = "lb_Cedula";
            this.lb_Cedula.Size = new System.Drawing.Size(43, 13);
            this.lb_Cedula.TabIndex = 11;
            this.lb_Cedula.Text = "Cédula:";
            this.lb_Cedula.Click += new System.EventHandler(this.label1_Click);
            // 
            // lb_Apellido
            // 
            this.lb_Apellido.AutoSize = true;
            this.lb_Apellido.Location = new System.Drawing.Point(390, 93);
            this.lb_Apellido.Name = "lb_Apellido";
            this.lb_Apellido.Size = new System.Drawing.Size(47, 13);
            this.lb_Apellido.TabIndex = 12;
            this.lb_Apellido.Text = "Apellido:";
            this.lb_Apellido.Click += new System.EventHandler(this.lb_Apellido_Click);
            // 
            // lb_Nombre
            // 
            this.lb_Nombre.AutoSize = true;
            this.lb_Nombre.Location = new System.Drawing.Point(218, 94);
            this.lb_Nombre.Name = "lb_Nombre";
            this.lb_Nombre.Size = new System.Drawing.Size(47, 13);
            this.lb_Nombre.TabIndex = 13;
            this.lb_Nombre.Text = "Nombre:";
            this.lb_Nombre.Click += new System.EventHandler(this.lb_Nombre_Click);
            // 
            // lb_Direccion
            // 
            this.lb_Direccion.AutoSize = true;
            this.lb_Direccion.Location = new System.Drawing.Point(218, 120);
            this.lb_Direccion.Name = "lb_Direccion";
            this.lb_Direccion.Size = new System.Drawing.Size(55, 13);
            this.lb_Direccion.TabIndex = 14;
            this.lb_Direccion.Text = "Dirección:";
            this.lb_Direccion.Click += new System.EventHandler(this.lb_Direccion_Click);
            // 
            // lb_Carrera
            // 
            this.lb_Carrera.AutoSize = true;
            this.lb_Carrera.Location = new System.Drawing.Point(218, 146);
            this.lb_Carrera.Name = "lb_Carrera";
            this.lb_Carrera.Size = new System.Drawing.Size(44, 13);
            this.lb_Carrera.TabIndex = 15;
            this.lb_Carrera.Text = "Carrera:";
            this.lb_Carrera.Click += new System.EventHandler(this.lb_Carrera_Click);
            // 
            // lb_Edad
            // 
            this.lb_Edad.AutoSize = true;
            this.lb_Edad.Location = new System.Drawing.Point(390, 67);
            this.lb_Edad.Name = "lb_Edad";
            this.lb_Edad.Size = new System.Drawing.Size(35, 13);
            this.lb_Edad.TabIndex = 16;
            this.lb_Edad.Text = "Edad:";
            this.lb_Edad.Click += new System.EventHandler(this.lb_Edad_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Berlin Sans FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(248, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 34);
            this.label1.TabIndex = 23;
            this.label1.Text = "Formulario Estudiante";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lb_SmsEliminar
            // 
            this.lb_SmsEliminar.AutoSize = true;
            this.lb_SmsEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SmsEliminar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lb_SmsEliminar.Location = new System.Drawing.Point(144, 177);
            this.lb_SmsEliminar.Name = "lb_SmsEliminar";
            this.lb_SmsEliminar.Size = new System.Drawing.Size(491, 13);
            this.lb_SmsEliminar.TabIndex = 24;
            this.lb_SmsEliminar.Text = "Para eliminar o modificar selecciona una fila de la lista y dele clic al botón re" +
    "spectivo";
            this.lb_SmsEliminar.Click += new System.EventHandler(this.label2_Click);
            // 
            // lb_TituloLista
            // 
            this.lb_TituloLista.AutoSize = true;
            this.lb_TituloLista.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TituloLista.Location = new System.Drawing.Point(308, 255);
            this.lb_TituloLista.Name = "lb_TituloLista";
            this.lb_TituloLista.Size = new System.Drawing.Size(183, 26);
            this.lb_TituloLista.TabIndex = 25;
            this.lb_TituloLista.Text = "Lista Estudiantes";
            this.lb_TituloLista.Click += new System.EventHandler(this.lb_TituloLista_Click);
            // 
            // pb_ReturnDelFormStudent
            // 
            this.pb_ReturnDelFormStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pb_ReturnDelFormStudent.Image = global::Bibliotecas.Properties.Resources.baseline_arrow_back_black_18dp;
            this.pb_ReturnDelFormStudent.Location = new System.Drawing.Point(13, 9);
            this.pb_ReturnDelFormStudent.Name = "pb_ReturnDelFormStudent";
            this.pb_ReturnDelFormStudent.Size = new System.Drawing.Size(28, 29);
            this.pb_ReturnDelFormStudent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_ReturnDelFormStudent.TabIndex = 27;
            this.pb_ReturnDelFormStudent.TabStop = false;
            this.pb_ReturnDelFormStudent.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormEstudiante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(817, 470);
            this.Controls.Add(this.pb_ReturnDelFormStudent);
            this.Controls.Add(this.lb_TituloLista);
            this.Controls.Add(this.lb_SmsEliminar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_Edad);
            this.Controls.Add(this.lb_Carrera);
            this.Controls.Add(this.lb_Direccion);
            this.Controls.Add(this.lb_Nombre);
            this.Controls.Add(this.lb_Apellido);
            this.Controls.Add(this.lb_Cedula);
            this.Controls.Add(this.txt_Edad);
            this.Controls.Add(this.txt_Carrera);
            this.Controls.Add(this.txt_Direccion);
            this.Controls.Add(this.txt_Nombre);
            this.Controls.Add(this.txt_Apellido);
            this.Controls.Add(this.txt_Ci);
            this.Controls.Add(this.btn_Eliminar);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.btn_Agregar);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.MaximizeBox = false;
            this.Name = "FormEstudiante";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Formulario Estudiante";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ReturnDelFormStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_Agregar;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_Eliminar;
        private System.Windows.Forms.TextBox txt_Ci;
        private System.Windows.Forms.TextBox txt_Apellido;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_Direccion;
        private System.Windows.Forms.TextBox txt_Carrera;
        private System.Windows.Forms.TextBox txt_Edad;
        private System.Windows.Forms.Label lb_Cedula;
        private System.Windows.Forms.Label lb_Apellido;
        private System.Windows.Forms.Label lb_Nombre;
        private System.Windows.Forms.Label lb_Direccion;
        private System.Windows.Forms.Label lb_Carrera;
        private System.Windows.Forms.Label lb_Edad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_SmsEliminar;
        private System.Windows.Forms.Label lb_TituloLista;
        private System.Windows.Forms.PictureBox pb_ReturnDelFormStudent;
    }
}

