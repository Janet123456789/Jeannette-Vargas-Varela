﻿using Bibliotecas.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Migrations;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bibliotecas
{
    public partial class FormEstudiante : Form
    {
        public FormEstudiante()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var conexion = new BIBLIOTECA2Entities();
            var listar = from x in conexion.Estudiante
                         select x;
            dataGridView1.DataSource = listar.ToList();
            

        }

        //Metodos

       public void Refrescar()
        {
            var conexion = new BIBLIOTECA2Entities();
            var listar = from x in conexion.Estudiante
                         select x;

            dataGridView1.DataSource = listar.ToList();

        }


        public void Limpiar()
        {
            txt_Ci.Clear();
            txt_Apellido.Clear();
            txt_Nombre.Clear();
            txt_Direccion.Clear();
            txt_Carrera.Clear();
            txt_Edad.Clear();
        }


        //Eventos
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString());
            var conexion = new BIBLIOTECA2Entities();
            var oestudiante = conexion.Estudiante.Find(id);

            DialogResult mensaje = MessageBox.Show("Desea eliminar el estudiante", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (mensaje == DialogResult.Yes)
            {
                conexion.Estudiante.Remove(oestudiante);
                
            }
            else 
            {
            
            }

            
            conexion.SaveChanges();
            Refrescar();
            




        }

        private void button1_Click(object sender, EventArgs e)
        {
            var conexion = new BIBLIOTECA2Entities();
            var oestudiante = new Estudiante();

            oestudiante.CI = txt_Ci.Text;
            oestudiante.Apellido = txt_Apellido.Text;
            oestudiante.Nombre = txt_Nombre.Text;
            oestudiante.Direccion = txt_Direccion.Text;
            oestudiante.Carrera = txt_Carrera.Text;
            oestudiante.Edad = int.Parse(txt_Edad.Text);

            //Commit
            conexion.Estudiante.Add(oestudiante);
            conexion.SaveChanges();
            Refrescar();
            Limpiar();

            
        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString());
            var conexion = new BIBLIOTECA2Entities();
            var oestudiante = conexion.Estudiante.Find(id);
           

            DialogResult mensaje = MessageBox.Show("Desea modificar el estudiante", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (mensaje == DialogResult.Yes)
            {

                oestudiante.CI = txt_Ci.Text;
                oestudiante.Apellido = txt_Apellido.Text;
                oestudiante.Nombre = txt_Nombre.Text;
                oestudiante.Direccion = txt_Direccion.Text;
                oestudiante.Carrera = txt_Carrera.Text;
                oestudiante.Edad = int.Parse(txt_Edad.Text);

                conexion.Estudiante.AddOrUpdate(oestudiante);
                conexion.SaveChanges();
                Refrescar();
                Limpiar();
             



            }
            else
            {

            }
        }

        private void btn_Listar_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txt_Carrera_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Ci_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtModify_Cedula_TextChanged(object sender, EventArgs e)
        {

        }

        private void lb_Apellido_Click(object sender, EventArgs e)
        {

        }

        private void txt_Apellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtModify_Apellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void lb_Nombre_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           // VentanaPrincipal vP= new VentanaPrincipal();
            this.Close();
        }

        private void lb_TituloLista_Click(object sender, EventArgs e)
        {

        }

        private void lb_Edad_Click(object sender, EventArgs e)
        {

        }

        private void lb_Carrera_Click(object sender, EventArgs e)
        {

        }

        private void lb_Direccion_Click(object sender, EventArgs e)
        {

        }

        private void txt_Edad_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Direccion_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
