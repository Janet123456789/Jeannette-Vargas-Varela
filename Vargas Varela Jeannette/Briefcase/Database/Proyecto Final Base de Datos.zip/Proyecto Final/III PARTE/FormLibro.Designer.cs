﻿namespace Bibliotecas
{
    partial class FormLibro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_TituloLista = new System.Windows.Forms.Label();
            this.lb_TituloFomLibro = new System.Windows.Forms.Label();
            this.lb_Area = new System.Windows.Forms.Label();
            this.lb_Editorial = new System.Windows.Forms.Label();
            this.lb_Cedula = new System.Windows.Forms.Label();
            this.txt_Area = new System.Windows.Forms.TextBox();
            this.txt_Editorial = new System.Windows.Forms.TextBox();
            this.txt_Titulo = new System.Windows.Forms.TextBox();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_Agregar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lb_SmsEliminar = new System.Windows.Forms.Label();
            this.pb_ReturnDelFormLibro = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ReturnDelFormLibro)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_TituloLista
            // 
            this.lb_TituloLista.AutoSize = true;
            this.lb_TituloLista.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TituloLista.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lb_TituloLista.Location = new System.Drawing.Point(351, 251);
            this.lb_TituloLista.Name = "lb_TituloLista";
            this.lb_TituloLista.Size = new System.Drawing.Size(126, 26);
            this.lb_TituloLista.TabIndex = 45;
            this.lb_TituloLista.Text = "Lista Libros";
            this.lb_TituloLista.Click += new System.EventHandler(this.lb_TituloLista_Click);
            // 
            // lb_TituloFomLibro
            // 
            this.lb_TituloFomLibro.AutoSize = true;
            this.lb_TituloFomLibro.Font = new System.Drawing.Font("Berlin Sans FB", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_TituloFomLibro.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lb_TituloFomLibro.Location = new System.Drawing.Point(296, 14);
            this.lb_TituloFomLibro.Name = "lb_TituloFomLibro";
            this.lb_TituloFomLibro.Size = new System.Drawing.Size(231, 34);
            this.lb_TituloFomLibro.TabIndex = 43;
            this.lb_TituloFomLibro.Text = "Formulario Libro";
            this.lb_TituloFomLibro.Click += new System.EventHandler(this.label1_Click);
            // 
            // lb_Area
            // 
            this.lb_Area.AutoSize = true;
            this.lb_Area.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lb_Area.Location = new System.Drawing.Point(219, 136);
            this.lb_Area.Name = "lb_Area";
            this.lb_Area.Size = new System.Drawing.Size(32, 13);
            this.lb_Area.TabIndex = 39;
            this.lb_Area.Text = "Área:";
            // 
            // lb_Editorial
            // 
            this.lb_Editorial.AutoSize = true;
            this.lb_Editorial.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lb_Editorial.Location = new System.Drawing.Point(219, 109);
            this.lb_Editorial.Name = "lb_Editorial";
            this.lb_Editorial.Size = new System.Drawing.Size(47, 13);
            this.lb_Editorial.TabIndex = 38;
            this.lb_Editorial.Text = "Editorial:";
            this.lb_Editorial.Click += new System.EventHandler(this.lb_Apellido_Click);
            // 
            // lb_Cedula
            // 
            this.lb_Cedula.AutoSize = true;
            this.lb_Cedula.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lb_Cedula.Location = new System.Drawing.Point(219, 82);
            this.lb_Cedula.Name = "lb_Cedula";
            this.lb_Cedula.Size = new System.Drawing.Size(38, 13);
            this.lb_Cedula.TabIndex = 37;
            this.lb_Cedula.Text = "Título:";
            // 
            // txt_Area
            // 
            this.txt_Area.Location = new System.Drawing.Point(279, 130);
            this.txt_Area.Name = "txt_Area";
            this.txt_Area.Size = new System.Drawing.Size(272, 20);
            this.txt_Area.TabIndex = 33;
            // 
            // txt_Editorial
            // 
            this.txt_Editorial.Location = new System.Drawing.Point(279, 103);
            this.txt_Editorial.Name = "txt_Editorial";
            this.txt_Editorial.Size = new System.Drawing.Size(272, 20);
            this.txt_Editorial.TabIndex = 32;
            // 
            // txt_Titulo
            // 
            this.txt_Titulo.Location = new System.Drawing.Point(279, 76);
            this.txt_Titulo.Name = "txt_Titulo";
            this.txt_Titulo.Size = new System.Drawing.Size(272, 20);
            this.txt_Titulo.TabIndex = 31;
            this.txt_Titulo.TextChanged += new System.EventHandler(this.txt_Ci_TextChanged);
            // 
            // btn_modificar
            // 
            this.btn_modificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_modificar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_modificar.Location = new System.Drawing.Point(431, 197);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(75, 26);
            this.btn_modificar.TabIndex = 29;
            this.btn_modificar.Text = "Modificar";
            this.btn_modificar.UseVisualStyleBackColor = true;
            this.btn_modificar.Click += new System.EventHandler(this.btn_modificar_Click);
            // 
            // btn_Agregar
            // 
            this.btn_Agregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Agregar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Agregar.Location = new System.Drawing.Point(314, 197);
            this.btn_Agregar.Name = "btn_Agregar";
            this.btn_Agregar.Size = new System.Drawing.Size(75, 26);
            this.btn_Agregar.TabIndex = 28;
            this.btn_Agregar.Text = "Agregar";
            this.btn_Agregar.UseVisualStyleBackColor = true;
            this.btn_Agregar.Click += new System.EventHandler(this.btn_Agregar_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.MenuHighlight;
            this.dataGridView1.Location = new System.Drawing.Point(75, 289);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(661, 155);
            this.dataGridView1.TabIndex = 27;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lb_SmsEliminar
            // 
            this.lb_SmsEliminar.AutoSize = true;
            this.lb_SmsEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SmsEliminar.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lb_SmsEliminar.Location = new System.Drawing.Point(162, 165);
            this.lb_SmsEliminar.Name = "lb_SmsEliminar";
            this.lb_SmsEliminar.Size = new System.Drawing.Size(491, 13);
            this.lb_SmsEliminar.TabIndex = 47;
            this.lb_SmsEliminar.Text = "Para eliminar o modificar selecciona una fila de la lista y dele clic al botón re" +
    "spectivo";
            // 
            // pb_ReturnDelFormLibro
            // 
            this.pb_ReturnDelFormLibro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pb_ReturnDelFormLibro.Image = global::Bibliotecas.Properties.Resources.baseline_arrow_back_black_18dp;
            this.pb_ReturnDelFormLibro.Location = new System.Drawing.Point(13, 9);
            this.pb_ReturnDelFormLibro.Name = "pb_ReturnDelFormLibro";
            this.pb_ReturnDelFormLibro.Size = new System.Drawing.Size(28, 29);
            this.pb_ReturnDelFormLibro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_ReturnDelFormLibro.TabIndex = 48;
            this.pb_ReturnDelFormLibro.TabStop = false;
            this.pb_ReturnDelFormLibro.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormLibro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 465);
            this.Controls.Add(this.pb_ReturnDelFormLibro);
            this.Controls.Add(this.lb_SmsEliminar);
            this.Controls.Add(this.lb_TituloLista);
            this.Controls.Add(this.lb_TituloFomLibro);
            this.Controls.Add(this.lb_Area);
            this.Controls.Add(this.lb_Editorial);
            this.Controls.Add(this.lb_Cedula);
            this.Controls.Add(this.txt_Area);
            this.Controls.Add(this.txt_Editorial);
            this.Controls.Add(this.txt_Titulo);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.btn_Agregar);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.Color.MidnightBlue;
            this.MaximizeBox = false;
            this.Name = "FormLibro";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Formulario Libro";
            this.Load += new System.EventHandler(this.FormLibro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ReturnDelFormLibro)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lb_TituloLista;
        private System.Windows.Forms.Label lb_TituloFomLibro;
        private System.Windows.Forms.Label lb_Area;
        private System.Windows.Forms.Label lb_Editorial;
        private System.Windows.Forms.Label lb_Cedula;
        private System.Windows.Forms.TextBox txt_Area;
        private System.Windows.Forms.TextBox txt_Editorial;
        private System.Windows.Forms.TextBox txt_Titulo;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_Agregar;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lb_SmsEliminar;
        private System.Windows.Forms.PictureBox pb_ReturnDelFormLibro;
    }
}