﻿using Bibliotecas.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Migrations;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bibliotecas
{
    public partial class FormLibro : Form
    {
        public FormLibro()
        {
            InitializeComponent();
        }

        //Métodos

        public void Refrescar()
        {
            var conexion = new BIBLIOTECA2Entities();
            var listar = from x in conexion.Libro
                         select x;

            dataGridView1.DataSource = listar.ToList();

        }


        public void Limpiar()
        {
            txt_Titulo.Clear();
            txt_Editorial.Clear();
            txt_Area.Clear();   
        }

        //Eventos

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lb_Apellido_Click(object sender, EventArgs e)
        {

        }

        private void btn_Devolver1_Click(object sender, EventArgs e)
        {
           // VentanaPrincipal vP = new VentanaPrincipal();
            this.Close();
        }

        private void btn_Agregar_Click(object sender, EventArgs e)
        {
            var conexion = new BIBLIOTECA2Entities();
            var olibro = new Libro();

            olibro.Titulo = txt_Titulo.Text;
            olibro.Editorial = txt_Editorial.Text;
            olibro.Area = txt_Area.Text;


            //Commit
            conexion.Libro.Add(olibro);
            conexion.SaveChanges();
            Refrescar();
            Limpiar();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormLibro_Load(object sender, EventArgs e)
        {
            var conexion = new BIBLIOTECA2Entities();
            var listar = from x in conexion.Libro
                         select x; 
            dataGridView1.DataSource = listar.ToList();
        }

        private void txt_Ci_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString());
            var conexion = new BIBLIOTECA2Entities();
            var olibro = conexion.Libro.Find(id);


            DialogResult mensaje = MessageBox.Show("Desea modificar el libro", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (mensaje == DialogResult.Yes)
            {

                olibro.Titulo = txt_Titulo.Text;
                olibro.Editorial = txt_Editorial.Text;
                olibro.Area = txt_Area.Text;

                conexion.Libro.AddOrUpdate(olibro);
                conexion.SaveChanges();

                //Llamado de los Métodos
                Refrescar();
                Limpiar();

            }
            else
            {

            }
        }

        private void btn_Eliminar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString());
            var conexion = new BIBLIOTECA2Entities();
            var olibro = conexion.Libro.Find(id);

            DialogResult mensaje = MessageBox.Show("Desea eliminar el libro", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (mensaje == DialogResult.Yes)
            {
                conexion.Libro.Remove(olibro);

            }
            else
            {

            }


            conexion.SaveChanges();
            Refrescar();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void lb_TituloLista_Click(object sender, EventArgs e)
        {

        }
    }
}
